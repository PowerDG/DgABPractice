export interface ChangeLanguagaInput {
  languageName: string;
}
