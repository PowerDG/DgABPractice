export default interface UpdateTenantOutput {
  tenancyName: string;
  name: string;
  isActive: boolean;
  id: number;
}
