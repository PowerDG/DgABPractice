export class EntityDto<T = number> {
  id: T;
}
