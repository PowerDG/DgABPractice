export interface IsTenantAvaibleInput {
  tenancyName: string;
}
