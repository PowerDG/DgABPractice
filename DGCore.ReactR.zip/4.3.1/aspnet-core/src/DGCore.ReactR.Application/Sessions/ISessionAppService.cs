﻿using System.Threading.Tasks;
using Abp.Application.Services;
using DGCore.ReactR.Sessions.Dto;

namespace DGCore.ReactR.Sessions
{
    public interface ISessionAppService : IApplicationService
    {
        Task<GetCurrentLoginInformationsOutput> GetCurrentLoginInformations();
    }
}
