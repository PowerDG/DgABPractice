﻿using System.Threading.Tasks;
using Abp.Authorization;
using Abp.Runtime.Session;
using DGCore.ReactR.Configuration.Dto;

namespace DGCore.ReactR.Configuration
{
    [AbpAuthorize]
    public class ConfigurationAppService : ReactRAppServiceBase, IConfigurationAppService
    {
        public async Task ChangeUiTheme(ChangeUiThemeInput input)
        {
            await SettingManager.ChangeSettingForUserAsync(AbpSession.ToUserIdentifier(), AppSettingNames.UiTheme, input.Theme);
        }
    }
}
