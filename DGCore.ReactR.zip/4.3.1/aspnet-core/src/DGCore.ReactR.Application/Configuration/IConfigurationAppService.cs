﻿using System.Threading.Tasks;
using DGCore.ReactR.Configuration.Dto;

namespace DGCore.ReactR.Configuration
{
    public interface IConfigurationAppService
    {
        Task ChangeUiTheme(ChangeUiThemeInput input);
    }
}
