﻿using Abp.AutoMapper;
using Abp.Modules;
using Abp.Reflection.Extensions;
using DGCore.ReactR.Authorization;

namespace DGCore.ReactR
{
    [DependsOn(
        typeof(ReactRCoreModule), 
        typeof(AbpAutoMapperModule))]
    public class ReactRApplicationModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.Authorization.Providers.Add<ReactRAuthorizationProvider>();
        }

        public override void Initialize()
        {
            var thisAssembly = typeof(ReactRApplicationModule).GetAssembly();

            IocManager.RegisterAssemblyByConvention(thisAssembly);

            Configuration.Modules.AbpAutoMapper().Configurators.Add(
                // Scan the assembly for classes which inherit from AutoMapper.Profile
                cfg => cfg.AddProfiles(thisAssembly)
            );
        }
    }
}
