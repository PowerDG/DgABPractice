using System.Threading.Tasks;
using Abp.Application.Services;
using Abp.Application.Services.Dto;
using DGCore.ReactR.Roles.Dto;
using DGCore.ReactR.Users.Dto;

namespace DGCore.ReactR.Users
{
    public interface IUserAppService : IAsyncCrudAppService<UserDto, long, PagedUserResultRequestDto, CreateUserDto, UserDto>
    {
        Task<ListResultDto<RoleDto>> GetRoles();

        Task ChangeLanguage(ChangeUserLanguageDto input);
    }
}
