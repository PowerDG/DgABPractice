using System.ComponentModel.DataAnnotations;

namespace DGCore.ReactR.Users.Dto
{
    public class ChangeUserLanguageDto
    {
        [Required]
        public string LanguageName { get; set; }
    }
}