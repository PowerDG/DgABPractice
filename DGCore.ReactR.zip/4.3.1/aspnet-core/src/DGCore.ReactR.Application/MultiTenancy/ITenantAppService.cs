﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using DGCore.ReactR.MultiTenancy.Dto;

namespace DGCore.ReactR.MultiTenancy
{
    public interface ITenantAppService : IAsyncCrudAppService<TenantDto, int, PagedTenantResultRequestDto, CreateTenantDto, TenantDto>
    {
    }
}

