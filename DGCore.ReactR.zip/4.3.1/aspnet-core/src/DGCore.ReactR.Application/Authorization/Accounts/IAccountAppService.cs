﻿using System.Threading.Tasks;
using Abp.Application.Services;
using DGCore.ReactR.Authorization.Accounts.Dto;

namespace DGCore.ReactR.Authorization.Accounts
{
    public interface IAccountAppService : IApplicationService
    {
        Task<IsTenantAvailableOutput> IsTenantAvailable(IsTenantAvailableInput input);

        Task<RegisterOutput> Register(RegisterInput input);
    }
}
