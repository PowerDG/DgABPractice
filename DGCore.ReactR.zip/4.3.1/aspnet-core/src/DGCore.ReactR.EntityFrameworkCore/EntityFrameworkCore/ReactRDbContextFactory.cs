﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using DGCore.ReactR.Configuration;
using DGCore.ReactR.Web;

namespace DGCore.ReactR.EntityFrameworkCore
{
    /* This class is needed to run "dotnet ef ..." commands from command line on development. Not used anywhere else */
    public class ReactRDbContextFactory : IDesignTimeDbContextFactory<ReactRDbContext>
    {
        public ReactRDbContext CreateDbContext(string[] args)
        {
            var builder = new DbContextOptionsBuilder<ReactRDbContext>();
            var configuration = AppConfigurations.Get(WebContentDirectoryFinder.CalculateContentRootFolder());

            ReactRDbContextConfigurer.Configure(builder, configuration.GetConnectionString(ReactRConsts.ConnectionStringName));

            return new ReactRDbContext(builder.Options);
        }
    }
}
