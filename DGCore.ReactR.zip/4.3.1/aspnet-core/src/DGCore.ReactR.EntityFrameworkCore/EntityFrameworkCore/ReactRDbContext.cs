﻿using Microsoft.EntityFrameworkCore;
using Abp.Zero.EntityFrameworkCore;
using DGCore.ReactR.Authorization.Roles;
using DGCore.ReactR.Authorization.Users;
using DGCore.ReactR.MultiTenancy;

namespace DGCore.ReactR.EntityFrameworkCore
{
    public class ReactRDbContext : AbpZeroDbContext<Tenant, Role, User, ReactRDbContext>
    {
        /* Define a DbSet for each entity of the application */
        
        public ReactRDbContext(DbContextOptions<ReactRDbContext> options)
            : base(options)
        {
        }
    }
}
