using System.Data.Common;
using Microsoft.EntityFrameworkCore;

namespace DGCore.ReactR.EntityFrameworkCore
{
    public static class ReactRDbContextConfigurer
    {
        public static void Configure(DbContextOptionsBuilder<ReactRDbContext> builder, string connectionString)
        {
            builder.UseSqlServer(connectionString);
        }

        public static void Configure(DbContextOptionsBuilder<ReactRDbContext> builder, DbConnection connection)
        {
            builder.UseSqlServer(connection);
        }
    }
}
