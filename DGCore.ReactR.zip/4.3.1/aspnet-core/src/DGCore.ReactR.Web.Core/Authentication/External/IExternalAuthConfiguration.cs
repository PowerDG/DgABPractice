﻿using System.Collections.Generic;

namespace DGCore.ReactR.Authentication.External
{
    public interface IExternalAuthConfiguration
    {
        List<ExternalLoginProviderInfo> Providers { get; }
    }
}
