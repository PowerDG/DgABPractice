using Microsoft.AspNetCore.Antiforgery;
using DGCore.ReactR.Controllers;

namespace DGCore.ReactR.Web.Host.Controllers
{
    public class AntiForgeryController : ReactRControllerBase
    {
        private readonly IAntiforgery _antiforgery;

        public AntiForgeryController(IAntiforgery antiforgery)
        {
            _antiforgery = antiforgery;
        }

        public void GetToken()
        {
            _antiforgery.SetCookieTokenAndHeader(HttpContext);
        }
    }
}
