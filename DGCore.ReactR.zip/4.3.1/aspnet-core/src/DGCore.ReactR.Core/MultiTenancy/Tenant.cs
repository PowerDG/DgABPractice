﻿using Abp.MultiTenancy;
using DGCore.ReactR.Authorization.Users;

namespace DGCore.ReactR.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}
