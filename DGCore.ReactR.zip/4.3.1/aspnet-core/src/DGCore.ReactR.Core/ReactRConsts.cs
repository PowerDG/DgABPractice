﻿namespace DGCore.ReactR
{
    public class ReactRConsts
    {
        public const string LocalizationSourceName = "ReactR";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
