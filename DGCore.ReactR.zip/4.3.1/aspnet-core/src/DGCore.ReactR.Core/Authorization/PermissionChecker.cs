﻿using Abp.Authorization;
using DGCore.ReactR.Authorization.Roles;
using DGCore.ReactR.Authorization.Users;

namespace DGCore.ReactR.Authorization
{
    public class PermissionChecker : PermissionChecker<Role, User>
    {
        public PermissionChecker(UserManager userManager)
            : base(userManager)
        {
        }
    }
}
