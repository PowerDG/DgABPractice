﻿using Volo.Abp.DependencyInjection;

namespace DGCorERM.API
{
    public class APITestData : ISingletonDependency
    {
    }
}
