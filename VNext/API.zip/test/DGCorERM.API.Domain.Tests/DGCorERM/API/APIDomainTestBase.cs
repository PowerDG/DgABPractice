﻿namespace DGCorERM.API
{
    public abstract class APIDomainTestBase : APITestBase<APIDomainTestModule>
    {

    }
}