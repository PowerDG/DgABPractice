﻿namespace DGCorERM.API.MongoDB
{
    public class MyEntityRepository_Tests : MyEntityRepository_Tests<APIMongoDbTestModule>
    {

    }
}
