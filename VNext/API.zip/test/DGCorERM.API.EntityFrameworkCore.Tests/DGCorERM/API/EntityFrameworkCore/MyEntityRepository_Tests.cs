﻿namespace DGCorERM.API.EntityFrameworkCore
{
    public class MyEntityRepository_Tests : MyEntityRepository_Tests<APIEntityFrameworkCoreTestModule>
    {

    }
}
