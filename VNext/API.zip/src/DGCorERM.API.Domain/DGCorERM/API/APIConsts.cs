﻿namespace DGCorERM.API
{
    public static class APIConsts
    {
        public const string DefaultDbTablePrefix = "API";

        public const string DefaultDbSchema = null;
    }
}
