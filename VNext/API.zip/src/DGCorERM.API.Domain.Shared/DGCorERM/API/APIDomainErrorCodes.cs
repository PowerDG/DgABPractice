﻿namespace DGCorERM.API
{
    public static class APIDomainErrorCodes
    {
        //Add your business exception error codes here...
    }
}
