﻿using Volo.Abp.Localization;

namespace DGCorERM.API.Localization
{
    [LocalizationResourceName("API")]
    public class APIResource
    {
        
    }
}
