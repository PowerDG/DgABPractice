﻿namespace DGCorERM.API
{
    public static class APISettings
    {
        public const string GroupName = "API";

        /* Add constants for setting names. Example:
         * public const string MySettingName = GroupName + ".MySettingName";
         */
    }
}