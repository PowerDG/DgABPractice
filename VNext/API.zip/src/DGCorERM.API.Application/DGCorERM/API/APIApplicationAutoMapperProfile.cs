﻿using AutoMapper;

namespace DGCorERM.API
{
    public class APIApplicationAutoMapperProfile : Profile
    {
        public APIApplicationAutoMapperProfile()
        {
            
        }
    }
}