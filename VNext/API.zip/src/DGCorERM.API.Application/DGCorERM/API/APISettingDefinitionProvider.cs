﻿using Volo.Abp.Settings;

namespace DGCorERM.API
{
    public class APISettingDefinitionProvider : SettingDefinitionProvider
    {
        public override void Define(ISettingDefinitionContext context)
        {
            /* Define module settings here.
             * Use names from APISettings class.
             */
        }
    }
}