﻿namespace DGCorERM.MVC.Settings
{
    public static class MVCSettings
    {
        private const string Prefix = "MVC";

        //Add your own setting names here. Example:
        //public const string MySetting1 = Prefix + ".MySetting1";
    }
}