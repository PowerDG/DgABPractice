﻿using Volo.Abp.Localization;

namespace DGCorERM.MVC.Localization.MVC
{
    [LocalizationResourceName("MVC")]
    public class MVCResource
    {

    }
}