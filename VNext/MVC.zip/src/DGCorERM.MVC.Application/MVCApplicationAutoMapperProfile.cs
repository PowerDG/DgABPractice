﻿using AutoMapper;

namespace DGCorERM.MVC
{
    public class MVCApplicationAutoMapperProfile : Profile
    {
        public MVCApplicationAutoMapperProfile()
        {
            //Configure your AutoMapper mapping configuration here...
        }
    }
}
