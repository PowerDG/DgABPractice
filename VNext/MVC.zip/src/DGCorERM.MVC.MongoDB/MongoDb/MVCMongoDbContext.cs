﻿using Volo.Abp.Data;
using Volo.Abp.MongoDB;

namespace DGCorERM.MVC.MongoDb
{
    [ConnectionStringName("Default")]
    public class MVCMongoDbContext : AbpMongoDbContext
    {
        
    }
}
