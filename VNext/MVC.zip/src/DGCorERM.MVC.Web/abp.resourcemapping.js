﻿module.exports = {
    aliases: {
        
    },
    mappings: {
        
    }
}