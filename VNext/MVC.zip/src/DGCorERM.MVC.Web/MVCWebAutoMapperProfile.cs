﻿using AutoMapper;

namespace DGCorERM.MVC
{
    public class MVCWebAutoMapperProfile : Profile
    {
        public MVCWebAutoMapperProfile()
        {
            //Configure your AutoMapper mapping configuration here...
        }
    }
}
