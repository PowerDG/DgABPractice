﻿namespace DGCorERM.MVC.Pages
{
    public class IndexModel : MVCPageModelBase
    {
        public void OnGet()
        {
            
        }
    }
}