using Microsoft.AspNetCore.Antiforgery;
using DGCore.VueR.Controllers;

namespace DGCore.VueR.Web.Host.Controllers
{
    public class AntiForgeryController : VueRControllerBase
    {
        private readonly IAntiforgery _antiforgery;

        public AntiForgeryController(IAntiforgery antiforgery)
        {
            _antiforgery = antiforgery;
        }

        public void GetToken()
        {
            _antiforgery.SetCookieTokenAndHeader(HttpContext);
        }
    }
}
