﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Abp.Modules;
using Abp.Reflection.Extensions;
using DGCore.VueR.Configuration;

namespace DGCore.VueR.Web.Host.Startup
{
    [DependsOn(
       typeof(VueRWebCoreModule))]
    public class VueRWebHostModule: AbpModule
    {
        private readonly IHostingEnvironment _env;
        private readonly IConfigurationRoot _appConfiguration;

        public VueRWebHostModule(IHostingEnvironment env)
        {
            _env = env;
            _appConfiguration = env.GetAppConfiguration();
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(VueRWebHostModule).GetAssembly());
        }
    }
}
