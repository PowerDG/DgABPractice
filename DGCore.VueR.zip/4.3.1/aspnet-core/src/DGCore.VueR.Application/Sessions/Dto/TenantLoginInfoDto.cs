﻿using Abp.Application.Services.Dto;
using Abp.AutoMapper;
using DGCore.VueR.MultiTenancy;

namespace DGCore.VueR.Sessions.Dto
{
    [AutoMapFrom(typeof(Tenant))]
    public class TenantLoginInfoDto : EntityDto
    {
        public string TenancyName { get; set; }

        public string Name { get; set; }
    }
}
