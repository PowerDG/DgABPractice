﻿using System.Threading.Tasks;
using Abp.Application.Services;
using DGCore.VueR.Sessions.Dto;

namespace DGCore.VueR.Sessions
{
    public interface ISessionAppService : IApplicationService
    {
        Task<GetCurrentLoginInformationsOutput> GetCurrentLoginInformations();
    }
}
