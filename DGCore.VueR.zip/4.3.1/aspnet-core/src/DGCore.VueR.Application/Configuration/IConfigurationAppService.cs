﻿using System.Threading.Tasks;
using DGCore.VueR.Configuration.Dto;

namespace DGCore.VueR.Configuration
{
    public interface IConfigurationAppService
    {
        Task ChangeUiTheme(ChangeUiThemeInput input);
    }
}
