﻿using Abp.AutoMapper;
using Abp.Modules;
using Abp.Reflection.Extensions;
using DGCore.VueR.Authorization;

namespace DGCore.VueR
{
    [DependsOn(
        typeof(VueRCoreModule), 
        typeof(AbpAutoMapperModule))]
    public class VueRApplicationModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.Authorization.Providers.Add<VueRAuthorizationProvider>();
        }

        public override void Initialize()
        {
            var thisAssembly = typeof(VueRApplicationModule).GetAssembly();

            IocManager.RegisterAssemblyByConvention(thisAssembly);

            Configuration.Modules.AbpAutoMapper().Configurators.Add(
                // Scan the assembly for classes which inherit from AutoMapper.Profile
                cfg => cfg.AddProfiles(thisAssembly)
            );
        }
    }
}
