using System.ComponentModel.DataAnnotations;

namespace DGCore.VueR.Users.Dto
{
    public class ChangeUserLanguageDto
    {
        [Required]
        public string LanguageName { get; set; }
    }
}