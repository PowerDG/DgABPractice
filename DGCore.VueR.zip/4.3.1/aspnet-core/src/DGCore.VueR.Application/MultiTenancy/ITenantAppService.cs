﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using DGCore.VueR.MultiTenancy.Dto;

namespace DGCore.VueR.MultiTenancy
{
    public interface ITenantAppService : IAsyncCrudAppService<TenantDto, int, PagedTenantResultRequestDto, CreateTenantDto, TenantDto>
    {
    }
}

