﻿using Microsoft.EntityFrameworkCore;
using Abp.Zero.EntityFrameworkCore;
using DGCore.VueR.Authorization.Roles;
using DGCore.VueR.Authorization.Users;
using DGCore.VueR.MultiTenancy;

namespace DGCore.VueR.EntityFrameworkCore
{
    public class VueRDbContext : AbpZeroDbContext<Tenant, Role, User, VueRDbContext>
    {
        /* Define a DbSet for each entity of the application */
        
        public VueRDbContext(DbContextOptions<VueRDbContext> options)
            : base(options)
        {
        }
    }
}
