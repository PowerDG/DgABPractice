using System.Data.Common;
using Microsoft.EntityFrameworkCore;

namespace DGCore.VueR.EntityFrameworkCore
{
    public static class VueRDbContextConfigurer
    {
        public static void Configure(DbContextOptionsBuilder<VueRDbContext> builder, string connectionString)
        {
            builder.UseSqlServer(connectionString);
        }

        public static void Configure(DbContextOptionsBuilder<VueRDbContext> builder, DbConnection connection)
        {
            builder.UseSqlServer(connection);
        }
    }
}
