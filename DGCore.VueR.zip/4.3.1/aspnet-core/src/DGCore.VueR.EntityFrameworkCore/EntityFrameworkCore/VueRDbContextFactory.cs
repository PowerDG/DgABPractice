﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using DGCore.VueR.Configuration;
using DGCore.VueR.Web;

namespace DGCore.VueR.EntityFrameworkCore
{
    /* This class is needed to run "dotnet ef ..." commands from command line on development. Not used anywhere else */
    public class VueRDbContextFactory : IDesignTimeDbContextFactory<VueRDbContext>
    {
        public VueRDbContext CreateDbContext(string[] args)
        {
            var builder = new DbContextOptionsBuilder<VueRDbContext>();
            var configuration = AppConfigurations.Get(WebContentDirectoryFinder.CalculateContentRootFolder());

            VueRDbContextConfigurer.Configure(builder, configuration.GetConnectionString(VueRConsts.ConnectionStringName));

            return new VueRDbContext(builder.Options);
        }
    }
}
