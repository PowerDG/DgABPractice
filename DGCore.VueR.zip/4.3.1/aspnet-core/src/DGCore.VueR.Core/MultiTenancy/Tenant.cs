﻿using Abp.MultiTenancy;
using DGCore.VueR.Authorization.Users;

namespace DGCore.VueR.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}
