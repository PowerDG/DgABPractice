﻿using Abp.Authorization;
using DGCore.VueR.Authorization.Roles;
using DGCore.VueR.Authorization.Users;

namespace DGCore.VueR.Authorization
{
    public class PermissionChecker : PermissionChecker<Role, User>
    {
        public PermissionChecker(UserManager userManager)
            : base(userManager)
        {
        }
    }
}
