﻿namespace DGCore.VueR
{
    public class VueRConsts
    {
        public const string LocalizationSourceName = "VueR";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
