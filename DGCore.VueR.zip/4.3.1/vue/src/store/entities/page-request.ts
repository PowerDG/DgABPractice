export default class  PagedFilterAndSortedRequest{
    maxResultCount:number;
    skipCount:number;
    sorting:string;
    where:string;
}