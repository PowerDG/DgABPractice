﻿using Abp.MultiTenancy;
using DgCorER.Authorization.Users;

namespace DgCorER.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}
