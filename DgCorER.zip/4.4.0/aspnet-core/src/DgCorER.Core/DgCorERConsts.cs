﻿namespace DgCorER
{
    public class DgCorERConsts
    {
        public const string LocalizationSourceName = "DgCorER";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
