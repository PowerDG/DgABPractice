using System.ComponentModel.DataAnnotations;

namespace DgCorER.Users.Dto
{
    public class ChangeUserLanguageDto
    {
        [Required]
        public string LanguageName { get; set; }
    }
}