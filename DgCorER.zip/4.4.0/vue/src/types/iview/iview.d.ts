declare module 'iview' {
  const iView: any;
  export default iView;
}